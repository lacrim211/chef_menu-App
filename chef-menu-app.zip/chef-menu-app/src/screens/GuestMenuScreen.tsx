import React, { useState } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../App';
import { usePantry, Course, Meal } from '../context/FoodContext';
import { Picker } from '@react-native-picker/picker';

type Props = NativeStackScreenProps<RootStackParamList, 'GuestMenu'>;

export default function GuestMenuScreen({ navigation }: Props) {
  const { getMealsByCourse } = usePantry();
  const [filter, setFilter] = useState<'All' | Course>('All');

  const meals = getMealsByCourse(filter);

  const renderItem = ({ item }: { item: Meal }) => (
    <View style={styles.item}>
      <View style={{ flex: 1 }}>
        <Text style={styles.title}>{item.name}</Text>
        <Text>{item.course} · R{item.price.toFixed(2)}</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Guest Menu</Text>

      <View style={styles.pickerWrap}>
        <Picker selectedValue={filter} onValueChange={(v) => setFilter(v as any)}>
          <Picker.Item label="All" value="All" />
          <Picker.Item label="Starter" value="Starter" />
          <Picker.Item label="Main" value="Main" />
          <Picker.Item label="Dessert" value="Dessert" />
          <Picker.Item label="Drink" value="Drink" />
        </Picker>
      </View>

      <FlatList data={meals} keyExtractor={(i) => i.id} renderItem={renderItem} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  header: { fontSize: 20, fontWeight: '700', marginBottom: 12 },
  pickerWrap: { borderWidth: 1, borderColor: '#ddd', borderRadius: 6, marginBottom: 12 },
  item: { flexDirection: 'row', padding: 12, borderBottomWidth: 1, borderColor: '#eee' },
  title: { fontSize: 16, fontWeight: '600' },
});
