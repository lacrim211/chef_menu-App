import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../App';
import { usePantry, Course } from '../context/FoodContext';
import { Picker } from '@react-native-picker/picker';

type Props = NativeStackScreenProps<RootStackParamList, 'NewMeal'>;

export default function NewMealScreen({ navigation }: Props) {
  const { addMeal } = usePantry();
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [course, setCourse] = useState<Course>('Main');

  const submit = () => {
    const parsed = parseFloat(price);
    if (!name.trim() || isNaN(parsed) || parsed <= 0) {
      Alert.alert('Validation', 'Please provide a valid name and price.');
      return;
    }
    addMeal({ name: name.trim(), price: parsed, course });
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Meal name</Text>
      <TextInput style={styles.input} value={name} onChangeText={setName} placeholder="e.g. Vegan Bowl" />

      <Text style={styles.label}>Price (R)</Text>
      <TextInput
        style={styles.input}
        value={price}
        onChangeText={setPrice}
        placeholder="e.g. 99.99"
        keyboardType="numeric"
      />

      <Text style={styles.label}>Course</Text>
      <View style={styles.pickerWrap}>
        <Picker selectedValue={course} onValueChange={(v) => setCourse(v as Course)}>
          <Picker.Item label="Starter" value="Starter" />
          <Picker.Item label="Main" value="Main" />
          <Picker.Item label="Dessert" value="Dessert" />
          <Picker.Item label="Drink" value="Drink" />
        </Picker>
      </View>

      <TouchableOpacity style={styles.saveBtn} onPress={submit}>
        <Text style={{ color: '#fff', fontWeight: '700' }}>Save Meal</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  label: { marginTop: 12, fontWeight: '600' },
  input: { borderWidth: 1, borderColor: '#ddd', padding: 10, borderRadius: 6, marginTop: 6 },
  pickerWrap: { borderWidth: 1, borderColor: '#ddd', borderRadius: 6, marginTop: 6 },
  saveBtn: { marginTop: 20, backgroundColor: '#28a745', padding: 12, borderRadius: 8, alignItems: 'center' },
});
