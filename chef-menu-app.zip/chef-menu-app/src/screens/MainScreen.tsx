import React from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../App';
import { usePantry, Meal } from '../context/FoodContext';

type Props = NativeStackScreenProps<RootStackParamList, 'Main'>;

export default function MainScreen({ navigation }: Props) {
  const { meals, removeMeal, getAveragesByCourse } = usePantry();

  const averages = getAveragesByCourse();

  const confirmRemove = (id: string) => {
    Alert.alert('Remove Meal', 'Are you sure you want to remove this meal?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: () => removeMeal(id),
      },
    ]);
  };

  const renderItem = ({ item }: { item: Meal }) => (
    <View style={styles.item}>
      <View style={{ flex: 1 }}>
        <Text style={styles.title}>{item.name}</Text>
        <Text>{item.course} · R{item.price.toFixed(2)}</Text>
      </View>
      <TouchableOpacity style={styles.removeBtn} onPress={() => confirmRemove(item.id)}>
        <Text style={{ color: '#fff' }}>Remove</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <Text style={styles.header}>Kitchen Menu</Text>
        <View style={styles.headerButtons}>
          <TouchableOpacity onPress={() => navigation.navigate('NewMeal')} style={styles.headerBtn}>
            <Text>Add</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('GuestMenu')} style={styles.headerBtn}>
            <Text>Guest</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.averages}>
        <Text style={styles.aveTitle}>Course Averages (R)</Text>
        <View style={styles.aveRow}>
          <Text>Starter: {averages.Starter.toFixed(2)}</Text>
          <Text>Main: {averages.Main.toFixed(2)}</Text>
        </View>
        <View style={styles.aveRow}>
          <Text>Dessert: {averages.Dessert.toFixed(2)}</Text>
          <Text>Drink: {averages.Drink.toFixed(2)}</Text>
        </View>
      </View>

      <FlatList
        data={meals}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={{ paddingBottom: 200 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  header: { fontSize: 22, fontWeight: '700' },
  headerButtons: { flexDirection: 'row' },
  headerBtn: { marginLeft: 10, padding: 8, borderWidth: 1, borderRadius: 6 },
  averages: { padding: 12, borderRadius: 8, backgroundColor: '#f5f5f5', marginBottom: 12 },
  aveTitle: { fontWeight: '700', marginBottom: 8 },
  aveRow: { flexDirection: 'row', justifyContent: 'space-between' },
  item: { flexDirection: 'row', padding: 12, borderBottomWidth: 1, borderColor: '#eee', alignItems: 'center' },
  title: { fontSize: 16, fontWeight: '600' },
  removeBtn: { backgroundColor: '#d9534f', padding: 8, borderRadius: 6 },
});
