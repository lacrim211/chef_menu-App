import React, { createContext, useContext, useState, ReactNode } from 'react';

export type Course = 'Starter' | 'Main' | 'Dessert' | 'Drink';

export type Meal = {
  id: string;
  name: string;
  price: number;
  course: Course;
  description?: string;
};

type FoodContextType = {
  meals: Meal[];
  addMeal: (meal: Omit<Meal, 'id'>) => void;
  removeMeal: (id: string) => void;
  getAveragesByCourse: () => Record<Course, number>;
  getMealsByCourse: (course: Course | 'All') => Meal[];
};

const FoodContext = createContext<FoodContextType | undefined>(undefined);

function generateId() {
  return Math.random().toString(36).substr(2, 9);
}

const initialMeals: Meal[] = [
  { id: generateId(), name: 'Tomato Bruschetta', price: 45, course: 'Starter' },
  { id: generateId(), name: 'Grilled Chicken', price: 120, course: 'Main' },
  { id: generateId(), name: 'Chocolate Mousse', price: 60, course: 'Dessert' },
  { id: generateId(), name: 'Iced Tea', price: 25, course: 'Drink' },
];

export const PantryProvider = ({ children }: { children: ReactNode }) => {
  const [meals, setMeals] = useState<Meal[]>(initialMeals);

  const addMeal = (meal: Omit<Meal, 'id'>) => {
    const newMeal: Meal = { id: generateId(), ...meal };
    setMeals((prev) => [newMeal, ...prev]);
  };

  const removeMeal = (id: string) => {
    setMeals((prev) => prev.filter((m) => m.id !== id));
  };

  const getAveragesByCourse = () => {
    const courses: Course[] = ['Starter', 'Main', 'Dessert', 'Drink'];
    const totals: Record<Course, { sum: number; count: number }> = {
      Starter: { sum: 0, count: 0 },
      Main: { sum: 0, count: 0 },
      Dessert: { sum: 0, count: 0 },
      Drink: { sum: 0, count: 0 },
    };

    // Use an explicit loop to compute totals (as requested)
    for (let i = 0; i < meals.length; i++) {
      const m = meals[i];
      totals[m.course].sum += m.price;
      totals[m.course].count += 1;
    }

    const averages: Record<Course, number> = {
      Starter: 0,
      Main: 0,
      Dessert: 0,
      Drink: 0,
    };

    for (let j = 0; j < courses.length; j++) {
      const c = courses[j];
      const t = totals[c];
      averages[c] = t.count > 0 ? Math.round((t.sum / t.count) * 100) / 100 : 0;
    }

    return averages;
  };

  const getMealsByCourse = (course: Course | 'All') => {
    if (course === 'All') return meals;
    const filtered: Meal[] = [];
    for (let i = 0; i < meals.length; i++) {
      if (meals[i].course === course) filtered.push(meals[i]);
    }
    return filtered;
  };

  return (
    <FoodContext.Provider value={{ meals, addMeal, removeMeal, getAveragesByCourse, getMealsByCourse }}>
      {children}
    </FoodContext.Provider>
  );
};

export const usePantry = () => {
  const ctx = useContext(FoodContext);
  if (!ctx) throw new Error('usePantry must be used within PantryProvider');
  return ctx;
};
